package application;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerServiceController {
	private static Map<String, Customer> customerRepo = new HashMap<>();
	static {
		Customer c1 = new Customer();
		c1.setId("1");
		c1.setName("vikram");
		customerRepo.put(c1.getId(), c1);

		Customer c2 = new Customer();
		c2.setId("2");
		c2.setName("arjun");
		customerRepo.put(c2.getId(), c2);
	}

	@RequestMapping(value = "/customers/{id}", method = RequestMethod.PUT)
	public ResponseEntity<String> updateCustomer(@PathVariable("id") String id, @RequestBody Customer customer) {

//		if (!customerRepo.containsKey(id)) throw new CustomerNotFoundException();
		try {
			remove(id);
		} catch (CustomerNotFoundException e) {
			return new ResponseEntity<>("Customer id not found", HttpStatus.OK);
		}
		customer.setId(id);
		customerRepo.put(id, customer);
		return new ResponseEntity<>("Customer is updated successfully", HttpStatus.OK);
	}
	
	public void remove(String custid) throws CustomerNotFoundException {
		if (!customerRepo.containsKey(custid)) throw new CustomerNotFoundException();
	}
}
