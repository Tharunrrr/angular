
package com.placingorder.daoimpl;

import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import com.placingorder.dao.PlacingorderDao;
import com.placingorder.db.DBUtil;
import com.placingorder.pojo.Placingorder;

public class PlacingorderDaosimpl implements PlacingorderDao {

	private Connection conn;
	
	public Placingorder insertOrder(Placingorder po) {	
	conn = DBUtil.getConnection();	
			try {
			String s2 = "insert into placing_order(order_id,date,time,quantity,itemid,price)values(?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(s2);
			ps.setInt(1, po.getOrder_Id());		
			ps.setString(2, po.getDate());	
			ps.setString(3, po.getTime());	
			ps.setInt(4, po.getQuantity());
			ps.setInt(5, po.getItemId());
			ps.setInt(6,po.getPrice());
			System.out.println("Prep Statement: " + ps.toString());
			ps.executeUpdate(); 
			System.out.println("record inserted"); 
			}
		catch(SQLException e)
		{			
				e.printStackTrace();
				}
			return fetchOrder(po.getOrder_Id());
		} 
			
			
			
			
//			placingOrder.setOrderId(1);  // 
//			placingOrder.setDate("2019-05-12");  // get it from current date
//			placingOrder.setTime("12:45:56");  // from current time
//			placingOrder.setQuantity(2);
//			placingOrder.setItemId(1);
//			placingOrder.setPrice(400);
//			insertOrder(placingOrder);
//			
			// search on the orderId only
			
		
			public Placingorder fetchOrder(int order_Id) {
				Placingorder placingOrderR = new Placingorder();
				try {
					String s1 = "select * from  placing_order where ITEMID=?";

			
			PreparedStatement pst = conn.prepareStatement(s1);
			pst.setInt(1, order_Id);
			
			ResultSet rs = pst.executeQuery();
			
			if (rs.next()) {
				placingOrderR.setOrder_Id(rs.getInt(1));
				placingOrderR.setDate(rs.getString("Date"));
				placingOrderR.setTime(rs.getString("time"));
				placingOrderR.setQuantity(rs.getInt(4));
				placingOrderR.setItemId(rs.getInt(5));
				
				placingOrderR.setPrice(rs.getInt(6));
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		DBUtil.closeConnection();
		return placingOrderR;
	}




				
	}



	
