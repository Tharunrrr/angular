package com.placingorder.appl;

import com.placingorder.dao.PlacingorderDao;
import com.placingorder.daoimpl.PlacingorderDaosimpl;
import com.placingorder.pojo.Placingorder;

public class OrderPlacingApplication {
	
	public  Placingorder insertOrder(Placingorder po) {		
		PlacingorderDao order = new PlacingorderDaosimpl();
		System.out.println("Welcome to OrderService");
		Placingorder orders = order.insertOrder(po);
		return orders;
		
	}
	
}	
	
//	public static void main(String args[]) {
//		
//		PlacingorderDao orderDao = new PlacingorderDaosimpl();
//		System.out.println("OrderPlacing Service");
//
//		Placingorder p2 = new Placingorder();
//		//System.out.println("enter the product to add");
//		p2.setOrderId(6);
//		p2.setDate("2019-11-03");
//		p2.setTime("06:48:23");
//		p2.setQuantity(1);
//		p2.setItemId(2);
//		p2.setPrice(300);
//		orderDao.insertOrder(p2);
//
//		
//		
//		// Parameters : ItemId,,quantity,PRICE
//	//Placingorder p1 = orderDao.fetchOrder(1);
//		System.out.println("Record Inserted: " 
//		        + "OrderID: " + p2.getOrderId() 
//		        + "\nDate: " + p2.getDate()
//		        + "\nTime: "+ p2.getTime()		     
//		        +"\nQuantity: " + p2.getQuantity() 
//		        +"\nItemID: " + p2.getItemId()
//		        +"\nPrice: "+ p2.getPrice());
//		
//		
//
//	}


