package com.placingorder.appl;

import com.placingorder.pojo.Placingorder;

public class OrderPlacingAppTest {

	public static void main(String[] args) {
		OrderPlacingApplication app = new OrderPlacingApplication();
		Placingorder po = new Placingorder();
		po.setOrder_Id(11);
		po.setDate("2019-11-03");
		po.setTime("06:48:23");
		po.setQuantity(1);
		po.setItemId(1);
		po.setPrice(150);
		app.insertOrder(po);
	}
}
