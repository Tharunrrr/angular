package com.placingorder.pojo;

public class Placingorder
{
	private int order_Id;
	private String date;
	private String time;
	private int quantity;
	private int itemId;
	private int price;
	public int getOrder_Id() {
		return order_Id;
	}
	public void setOrder_Id(int order_Id) {
		this.order_Id = order_Id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Placingorder [order_Id=" + order_Id + ", date=" + date + ", time=" + time + ", quantity=" + quantity
				+ ", itemId=" + itemId + ", price=" + price + "]";
	}
	
	
}