package com.placingorder.dao;

import com.placingorder.pojo.Placingorder;

public interface PlacingorderDao

{
	public Placingorder insertOrder(Placingorder po);
	public Placingorder fetchOrder(int order_Id);

}
